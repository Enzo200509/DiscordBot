module.exports = async (client) =>{
    const guild = client.guilds.cache.get('910281710724333589');
    setInterval(() =>{
        const memberCount = guild.memberCount;
        const channel = guild.channels.cache.get('910459695586746368');
        channel.setName(`Total Members: ${memberCount.toLocaleString()}`);
    }, 5000);
}