const Discord = require("discord.js");

module.exports.run = async (Client, message, args, prefix) => {
  if (!message.content.startWith(prefix)) return;

  let user = message.mention.users.first();
  if (!user) return message.reply("**Please mention a User");

  let nickname = args.slice(1).join(" ");
  if (!nickname) return message.reply("Please specify a nickname");

  let member = message.guild.members.cache.get(user.id);
  await member.setNickname(nickname);

  const embed = new Discord.MessageEmbed()
    .setTitle("Done!")
    .setDescription(
      "Successfully Changed ${user.tag}'s nickname to ${nickname}"
    )
    .setColor("RANDOM")
    .setTimestamp();
  message.channel.send(embed);
};

module.exports.help = {
  neme: "nick",
  aliases: ["nickname"],
};
